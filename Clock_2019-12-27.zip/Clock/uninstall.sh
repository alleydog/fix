#!/bin/bash
sudo rm /usr/lib/dde-dock/plugins/libclock.so
killall dde-dock