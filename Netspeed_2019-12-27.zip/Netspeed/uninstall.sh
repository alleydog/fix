#!/bin/bash
sudo rm /usr/lib/dde-dock/plugins/libnetspeed.so
killall dde-dock