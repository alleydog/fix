#!/bin/bash
sudo cp `dirname $0`/libweather.so /usr/lib/dde-dock/plugins/libweather.so
killall dde-dock