#!/bin/bash
sudo rm /usr/lib/dde-dock/plugins/libweather.so
killall dde-dock